package Models;

public class Administrateur extends User {

	public Administrateur(int id, String nomComplet, String email) {
		super(id, nomComplet, email);
		// TODO Auto-generated constructor stub
	}
}